package com.nik.golden.security.dto;

import lombok.Data;

@Data
public class RegisterDto {
    private String username;
    private String password;
}
